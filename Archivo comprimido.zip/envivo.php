<?php include( 'header.php'); ?>

<section id="inside-header">
</section>
<section id="content-inside">
  <div class="in-frame">
    <div class="content-header">
      <ul>
        <li>
          <div class="header-title-container">
            <h1>
              <!-- Inicio BreadCrumbs-->

              <a href="#">Ver / Escuchar  </a>/
              <span class="light">Vivo</span>

              <!-- Fin BreadCrumbs-->

            </h1>
          </div>
        </li>
        <li class="right-corner">
        </li>
      </ul>
    </div>


    <!--Inicio Contenido Dinámico-->


    <div class="inner-content template-full section-envivo">
      <div>
        <h1 class="tag-trama red">VIVO</h1>
        <div class="flex-video">
          <iframe width="560" height="315" src="https://www.youtube.com/embed/WUDoHznO9xI" frameborder="0" allowfullscreen></iframe>
        </div>
        <ul class="envivo-media-list">
          <li>
            <ul>
              <li>
                20/04
              </li>
              <li>
                <h2>Titulo Evento Próximo</h2>
                <h4>Bajada o Subtitulo</h4>
              </li>
              <li>
                <a href="#" class="button">Ver Avance</a>
              </li>
            </ul>
          </li>
          <li>
            <ul>
              <li>
                20/04
              </li>
              <li>
                <h2>Titulo Evento Próximo</h2>
                <h4>Bajada o Subtitulo</h4>
              </li>
              <li>
                <a href="#" class="button">Ver Avance</a>
              </li>
            </ul>
          </li>
          <li>
            <ul>
              <li>
                20/04
              </li>
              <li>
                <h2>Titulo Evento Próximo</h2>
                <h4>Bajada o Subtitulo</h4>
              </li>
              <li>
                <a href="#" class="button">Ver Avance</a>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </div>

    <!--Fin Contenido Dinámico-->

  </div>
  <!--.in-frame-->
</section>
<!--.content-inside-->

<?php include( 'footer.php'); ?>
