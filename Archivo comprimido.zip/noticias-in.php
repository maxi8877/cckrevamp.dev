<?php include( 'header.php'); ?>


<section id="inside-header">
</section>
<section id="content-inside">
  <div class="in-frame">
    <div class="content-header">
      <ul>
        <li>
          <div class="header-title-container">
            <h1>
              <!-- Inicio BreadCrumbs-->


              <a href="#">El Centro / </a>
              <span class="light"><a href="noticias.php">Noticias</a></span>

              <!-- Fin BreadCrumbs-->

            </h1>
            <p>
            </p>
          </div>
        </li>
        <li class="right-corner">
        </li>
      </ul>
    </div>
    <!--Inicio Contenido Dinámico-->


    <div class="inner-content template-sidebar-right section-noticias-in">

      <!-- Comienzo  Noticia  Simple-->

      <article>
        <figure>
          <img src="https://placeholdit.imgix.net/~text?txtsize=100&txt=4:3&w=800&h=600" />
          <figcaption>

          </figcaption>
        </figure>
        <header>
          <h1>
            De Vido y Recalde recorrieron el Centro Cultural Kirchner y firmaron convenios
          </h1>
        </header>


        <p>
          <strong>Pellentesque habitant morbi tristique</strong> senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper.
          <em>Aenean ultricies mi vitae est.</em> Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed,
          <code>commodo vitae</code>, ornare sit amet, wisi. Aenean fermentum, elit eget tincidunt condimentum, eros ipsum rutrum orci, sagittis tempus lacus enim ac dui. <a href="#">Donec non enim</a> in turpis pulvinar facilisis. Ut felis.</p>

        <footer>
        </footer>
      </article>
      <!-- fin Noticia Simple -->
    </div>

    <!--Inicio Barra Lateral-->


    <div id="secondary" class="right sticky-sidebar">

    </div>
    <!--Fin Barra Lateral-->

    <!--Fin Contenido Dinámico-->


  </div>
  <!--.in-frame-->
</section>
<!--.content-inside-->

<?php include( 'footer.php'); ?>
