<?php include( 'header.php'); ?>


<section id="inside-header">
</section>
<section id="content-inside">
  <div class="in-frame">
    <div class="content-header">
      <ul>
        <li>
          <div class="header-title-container">
            <h1>
              <!-- Inicio BreadCrumbs-->

              <a href="#">El centro / </a>
              <span class="light"><a href="salas.php">Salas</a> </span>
              <!-- Fin BreadCrumbs-->

            </h1>
          </div>
        </li>
        <li class="right-corner">
        </li>
      </ul>
    </div>


    <!--Inicio Contenido Dinámico-->

    <div class="inner-content template-sidebar-right">
      <article>
        <h1 class="">
          La ballena Azul
        </h1>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium
          quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.</p>

        <p>In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat
          vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.</p>
        <img src="https://placeholdit.imgix.net/~text?txtsize=100&txt=4:3&w=800&h=600" />
      </article>
    </div>

    <!--Inicio Barra Lateral-->
    <div id="secondary" class="right sticky-sidebar">
      <div class="sidebar-widget salas-sidebar">
        <ul>
          <li><a href="#">La Cúpula</a></li>
          <li><a href="#">La ballena Azul</a></li>
          <li><a href="#">Sala X</a></li>
          <li><a href="#">Pilar de Chandalier</a></li>
          <li><a href="#">Sala X</a></li>
          <li><a href="#">Sala X</a></li>
          <li><a href="#">Sala X</a></li>
        </ul>
      </div>
    </div>
    <!--Fin Barra Lateral-->


    <!--Fin Contenido Dinámico-->

  </div>
  <!--.in-frame-->
</section>
<!--.content-inside-->

<?php include( 'footer.php'); ?>
