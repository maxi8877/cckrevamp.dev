<?php include( 'header.php'); ?>


<section id="inside-header">
</section>
<section id="content-inside" class="static">
  <div class="in-frame">
    <div class="content-header">
      <ul>
        <li>
          <div class="header-title-container">
            <h1>

              <!-- Inicio BreadCrumbs-->

              <a href="#">El Centro / </a>
              <span class="light">Prensa / Gacetillas</span>

              <!-- Fin BreadCrumbs-->

            </h1>
            <p>
            </p>
          </div>
        </li>
        <li class="right-corner">
        </li>
      </ul>
    </div>



    <!--Inicio Contenido Dinámico-->


    <div class="inner-content template-sidebar-right section-gacetillas">

      <!-- Inicio loop de Gacetillas -->

      <article class="article-gacetillas item cat-escenicas">

        <figure>
          <img src="https://placeholdit.imgix.net/~text?txtsize=100&txt=4:3&w=800&h=600" />
          <figcaption>

          </figcaption>
        </figure>
        <header class=" gacetilla-body">
          <h4>
            <strong>artes escenicas</strong>
          </h4>
          <h1>
            Molly Bloom, Cristina Banegas
          </h1>
          <p></p>
          <a class="button" href="#">Descargar Gacetilla</a>
          <a class="button" href="#">Fotos</a>

        </header>
        <footer>
        </footer>
      </article>
      <hr/>

      <article class="article-gacetillas item cat-escenicas">

        <figure>
          <img src="https://placeholdit.imgix.net/~text?txtsize=100&txt=4:3&w=800&h=600" />
          <figcaption>

          </figcaption>
        </figure>
        <header class=" gacetilla-body">
          <h4>
            <strong>artes escenicas</strong>
          </h4>
          <h1>
            Molly Bloom, Cristina Banegas
          </h1>
          <p></p>
          <a class="button" href="#">Descargar Gacetilla</a>
          <a class="button" href="#">Fotos</a>

        </header>
        <footer>
        </footer>
      </article>
      <hr/>
      <article class="article-gacetillas item cat-escenicas">

        <figure>
          <img src="https://placeholdit.imgix.net/~text?txtsize=100&txt=4:3&w=800&h=600" />
          <figcaption>

          </figcaption>
        </figure>
        <header class=" gacetilla-body">
          <h4>
            <strong>artes escenicas</strong>
          </h4>
          <h1>
            Molly Bloom, Cristina Banegas
          </h1>
          <p></p>
          <a class="button" href="#">Descargar Gacetilla</a>
          <a class="button" href="#">Fotos</a>
        </header>
        <footer>
        </footer>
      </article>
      <hr>

      <!-- fin loop de Gacetillas -->

    </div>

    <!--Inicio Barra Lateral-->

    <div id="secondary" class="right">

      <div class="sidebar-prensa">
        <h2>
          Recursos Disponibles
        </h2>
        <ul>
          <li>
            <a href="gacetillas.php">Gacetillas</a>
          </li>
          <!-- <li>
            <a href="prensa.php">Notas</a>
          </li> -->
          <li>
            <a href="contacto.php">Contacto</a>
          </li>
        </ul>
      </div>
    </div>

    <!--Fin Barra Lateral-->

    <!--Fin Contenido Dinámico-->


  </div>
  <!--.in-frame-->
</section>
<!--.content-inside-->

<?php include( 'footer.php'); ?>
