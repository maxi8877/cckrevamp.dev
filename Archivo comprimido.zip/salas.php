<?php include( 'header.php'); ?>

<section id="inside-header">
</section>
<section id="content-inside">
  <div class="in-frame">
    <div class="content-header">
      <ul>
        <li>
          <div class="header-title-container">
            <h1>
              <!-- Inicio BreadCrumbs-->


              <a href="#">El centro / </a>
              <span class="light">Salas</span>
              <!-- Fin BreadCrumbs-->

            </h1>
          </div>
        </li>
        <li class="right-corner">
        </li>
      </ul>
    </div>
    <!--Inicio Contenido Dinámico-->
    <div class="inner-content template-full">
      <ul class="salas-container-2">
        <li>
          <ul>
            <li>
              <a href="salas-in.php"></a>
              <img src="assets/img/centro/salas-ver-2/1.jpg" />
              <div class="salas-caption">
                <a href="salas-in.php"></a>
                <h1 class="tag-trama cyan">La Cúpula</h1>
                <p>
                  Los técnicos alemanes de la firma Klais, comenzaron a hacer pruebas con el teclado.
                </p>
              </div>
            </li>
            <li>
              <a href="salas-in.php"></a>
              <img src="assets/img/centro/salas-ver-2/2.jpg" />
              <div class="salas-caption">
                <h1 class="tag-trama cyan">Sala X</h1>
              </div>
            </li>
          </ul>
        </li>
        <li>
          <ul>
            <li>
              <a href="salas-in.php"></a>
              <img src="assets/img/centro/salas-ver-2/2.jpg" />
              <div class="salas-caption">
                <h1 class="tag-trama cyan">Sala X</h1>

              </div>
            </li>
            <li>
              <a href="salas-in.php"></a>
              <img src="assets/img/centro/salas-ver-2/1.jpg" />
              <div class="salas-caption">
                <h1 class="tag-trama cyan">La Ballena Azul</h1>
                <p>
                  Los técnicos alemanes de la firma Klais, comenzaron a hacer pruebas con el teclado.
                </p>
              </div>
            </li>
          </ul>
        </li>
        <li>
          <ul>
            <li>
              <a href="salas-in.php"></a>
              <img src="assets/img/centro/salas-ver-2/1.jpg" />
              <div class="salas-caption">
                <h1 class="tag-trama cyan">Pilar de Chandelier</h1>
                <p>
                  Los técnicos alemanes de la firma Klais, comenzaron a hacer pruebas con el teclado.
                </p>
              </div>
            </li>
            <li>
              <a href="salas-in.php"></a>
              <img src="assets/img/centro/salas-ver-2/2.jpg" />
              <div class="salas-caption">
                <h1 class="tag-trama cyan">Sala X</h1>
              </div>
            </li>
          </ul>
        </li>
      </ul>
      <p class="clearfix"></p>
    </div>
    <!--Fin Contenido Dinámico-->

    </div>
    <!--.in-frame-->
    </section>
    <!--.content-inside-->

    <?php include( 'footer.php'); ?>
