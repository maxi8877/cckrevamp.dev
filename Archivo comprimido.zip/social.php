<?php include( 'header.php'); ?>
<section id="inside-header">
</section>
<section id="content-inside">
  <div class="in-frame">
    <div class="content-header">
      <ul>
        <li>
          <div class="header-title-container">
            <h1>
              <!-- Inicio BreadCrumbs-->

              <a href="#">El centro / </a>
              <span class="light">Redes Sociales</span>
              <!-- Fin BreadCrumbs-->

            </h1>
            <p>
            </p>
          </div>
        </li>
        <li class="right-corner">
        </li>
      </ul>
    </div>
    <!--Inicio Contenido Dinámico-->


    <div class="inner-content template-sidebar-right section-social">
      <article>
        <ul class="soc">
          <li>
            <a class="icon-social soc-twitter" href="#"></a>
            <a href="#">@cckirchner</a>
          </li>
          <li>
            <a class="icon-social soc-facebook" href="#"></a>
            <a href="#">facebook.com/cckirchner</a>
          </li>
          <!-- <li>
            <a class="icon-social soc-google" href="#"></a>
            <a href="#">plus.google.com/+cckirchner</a>
          </li> -->
          <!-- <li>
            <a class="icon-social soc-instagram" href="#"></a>
            <a href="#">instagram.com/cckirchner</a>
          </li> -->
          <li>
            <a class="icon-social soc-youtube" href="#"></a>
            <a href="#">youtube.com/cckirchner</a>
          </li>
          <!-- <li>
            <a class="icon-social soc-flickr" href="#"></a>
            <a href="#">flickr.com/cckirchner</a>
          </li>
          <li>
            <a class="icon-social soc-soundcloud" href="#"></a>
            <a href="#">soundcloud.com/cckirchner</a>
          </li>
          <li>
            <a class="icon-social soc-tumblr" href="#"></a>
            <a href="#">tumblr.com/cckirchner</a>
          </li>
          <li>
            <a class="icon-social soc-pinterest" href="#"></a>
            <a href="#">cckirchner</a>
          </li>
          <li>
            <a class="icon-social soc-vine soc-icon-last" href="#"></a>
            <a href="#">cck</a>
          </li>
          <li>
            <a class="icon-social soc-blogger" href="#"></a>
            <a href="#">blogger.com/centroculturalkirchner</a>
          </li> -->
        </ul>
      </article>
    </div>


    <!--Inicio Barra Lateral-->


    <div id="secondary" class="right">
      <div class="sidebar-widget newsletter-sidebar">
        <p>Subscribete anuestro newsletter y recibí novedades
        </p>
        <input type="text" class="newsletter-input" placeholder="Email" />
        <input id="submit_button" class="button" type="submit" value="Enviar" />
      </div>
    </div>

    <!--Fin Barra Lateral-->

    <!--Fin Contenido Dinámico-->

  </div>
  <!--.in-frame-->
</section>
<!--.content-inside-->

<?php include( 'footer.php'); ?>
